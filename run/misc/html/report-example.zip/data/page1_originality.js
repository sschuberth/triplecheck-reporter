/*
 * Graph sorting the files according to:
 *  - Original (authored)
 *  - External (authored by a third-party project or developer)
 *  - Auto-generated (not relevant from a copyright/license perspective)
 *  - Mixed code (Partly authored by a third-party, partly by this author)
 */
var fileOriginality = [47.27, 65.32, 84.59, 11.86];
