var files = [
   {
    "folders":
        [{
         "name":"Folder1",
         "children":
          [
            {
               "name":"Folder2",
               "children":
               [
                  {
                     "name":"File1",
                     "description":"Hello 1"
                 },
                  {
                     "name":"File2",
                     "description":"Hello 2"
                  }
               ]
            },
            {
               "name":"File3",
               "description":"Hello 3"
            },
            {
               "name":"File4",
               "description":"Hello 4"
            }
         ]
        }
   ]}
];