var licenseOverview = [{
        region: "GPL-3.0+ (93 files)",
        val: 0.20
    }, {
        region: "Apache-2.0 (29 files)",
        val: 0.15
    }, {
        region: "SPL-1.0 (20 files)",
        val: 0.35
    }, {
        region: "MIT (3 files)",
        val: 0.30
    }, {
        region: "BSD-3-Clause-Clear (2 files)",
        val: 0.10
    }];
