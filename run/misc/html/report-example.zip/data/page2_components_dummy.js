var components_list = [
    {title: "Adblock Plus for Android (315 files)", description: "23"},
    {
        title: "Brazil project web application toolkit (20 files)",
        description: "45"
    },{
        title: "Apache",
        description: "46"
    },{
        title: "Ideas",
        description: "48"
    },{
        title: "MySQL",
        description: "55"
    },{
        title: "Next",
        description: "65"
    }
];