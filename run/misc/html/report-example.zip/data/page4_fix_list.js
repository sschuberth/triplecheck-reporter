// What should be fixed on this project? 
var fix_copyright = "No <b>copyright</b> attribution was found for the <b>3</b> files listed below.<br><br>./files_minor.java<br>./python/portscanner.py<br>./TestServer.java<br>";
var fix_licenses = "No <b>license</b> reference was found for the <b>3</b> files listed below.<br><br>./files_minor.java<br>./python/portscanner.py<br>./TestServer.java<br>";
var fix_documentation = "Please create these <b>2</b> files:<br><br>./README<br><br>./LICENSE<br><br>";
