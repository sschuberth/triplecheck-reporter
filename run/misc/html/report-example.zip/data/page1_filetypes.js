var dataFileTypes = [
    {country: "HTML", green: 40, grey: 60}, 
    {country: "CSS", green: 51, grey: 49},
    {country: "Java", green: 51, grey: 49},
    {country: "C++", green: 11, grey: 89},
    {country: "JS", green: 16, grey: 84}
];

var fileTypeText = "<p style=\"margin-top:10px;\">116 HTML files<br />76 Java files  <br />13 Javascript files <br />12 C++ files  </p>";

var languageList = {
	"Basic": ["vbs", "bas", "vb"],
	"Lisp": ["el", "elc"],
	"Java": ["gradle", "prefs", "properties", "project", "form", "classpath", "jar", "java", "jsp"],
	"R": ["r"],
	"Ruby": ["yml", "rdoc", "erb", "gem", "gemfile", "gemspec", "rake", "rakefile", "rb", "lock"],
	"Windows script": ["bat", "cmd"],
	"Erlang": ["edoc", "erl"],
	"C": ["a", "res", "dsp", "dsw", "gcc", "inc", "mk", "prefs", "src", "pch", "c", "h", "ino", "makefile"],
	"Assembler": ["asm"],
	"Scala": ["scala"],
	"HTML": ["css", "htm", "html", "swf", "hhc", "hhk", "hhp"],
	"Delphi": ["res", "inc", "dcr", "dcu", "dfm", "dof", "dpk", "form", "lfm", "lpi", "lpk", "lpr", "lrs", "pas", "~pas"],
	"D": ["d"],
	"C++": ["a", "res", "dsp", "dsw", "gcc", "inc", "mak", "mk", "prefs", "cc", "cpp", "pch", "hpp", "def", "h", "makefile", "bpk"],
	"Perl": ["yml", "pl"],
	"PHP": ["prefs", "php"],
	"SQL": ["csv", "sql"],
	"ABAP": ["abap"],
	"Lua": ["lua"],
	"Javascript": ["npmignore", "yml", "json", "es", "js", "jsm", "less"],
	"Matlab": ["m", "mat"],
	"Linux script": ["rc", "sh"],
	"Python": ["yml", "py"],
	"Coffee script": ["coffee"],
	"Clojure": ["clj"],
	"Groovy": ["groovy"],
	"C#": ["pch", "cd", "config", "cs", "csproj", "resx", "ruleset", "sln", "userprefs"],
	"Haxe": ["hx"],
	"Go": ["go"]
};